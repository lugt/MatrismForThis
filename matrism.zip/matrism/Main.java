package matrism;

/**
 * Created by God on 2016/6/16.
 */
public class Main {
    public static void main(String... args){
        // Start Here
        Brainy bR = Brainy.Create();
        bR.prepare();
        while(true){
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
                return;
            }
        }
    }

}
