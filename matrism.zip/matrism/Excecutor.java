package matrism;

/**
 * Created by God on 2016/6/16.
 */
public class Excecutor {

    public static int StarterRatio = 5000;
    /*

       Define Most Highly Tolerable Algothyrms That
       Mathces the nature's laws as well as the
       law of evolution.

       Law Of Conservation On ...
       Law of Descendence (Minimizing)
       Law of Causiality
       Law of Consecutivity

         Every Neuron Has some (tools)
            by which it may commit its actions.
                by which the laws are demonstrated.

     */

    /* Fundamental Tools
        Are:

        MA1 To test polarization and do action

        MA2 To Move electos in
        MA3 To Move electos out
        MA4 Stop the movement

        MA5 Change the electros from one pole to another
        MA6 Test a Number In the Input

        MA7 Give a current to all axons.
        MA8 Rest the Potential

        MA9 Inject Energy From Environ
        MA10 Create New Neurons
        MA11 Outgive electro energy

        TA1 Reset the funcs
        TA2 Open Channels (Sync the ions)

        TA3 Connect Axon to a new neuron.

        TA4 Break a connection
        TA5 Enhance a connection
        TA6 Depict a connection

        QA1 Change the meaning - number assembly
        QA2 Change the Layer Neuron number
        QA3 Create a new Neuron
        QA4 Diminish Another Neuron

        QA5 Add a new func to n
        QA6 Remove a func from n
        QA7 Change a func in n
        QA8 Alter func order in n

        EP1 Send a move signal
        EP2 Send a heat signal

        EP3 Send a relax signal
        EP3 Send a fight signal

        EP4 Send a sleep signal
        EP5 delay signal

        EF1 Get the muscular signal level
        EF2 Get the pain level
        EF3 Get the happiness level
        EF4 Get the signal level
        EF5 Get the signal level


     */

    public static int BSize;
    public static void _(int ps, int at) {
        // Find ps'
        if(BrLayer.Ps.length <= ps){
            return;
        }

        switch (at){

            case 1:
                // Move Electrodes In For a While.
            case 97:
                // SP1  // To Create Connections\
                int m = BrLayer.Ps[ps].ConId.length;
                BrLayer.Ps[ps].ConId[m] = ps - 1;
                BrLayer.Ps[ps].ConRate[m] = StarterRatio;
                break;
            case 98:
                 // Leading the node to form new cons.
        }
    }
}
