package matrism;

/**
 * Created by God on 2016/6/16.
 */
public class Brainy {

    public BrainLayers bL;

    public static Brainy Create(){
        // Initialize One Instance Of Brain
        return new Brainy();
    }

    public void prepare() {
        // Initialize All Layers.
        bL = new BrainLayers();
    }


}
