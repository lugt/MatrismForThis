package matrism;

/**
 * Created by God on 2016/7/6.
 */
public class Cellular {

    /**
     *
     * */
    public int[] Key;
    public int[] ConId;
    public int[] ConRate;
    public Cellular(){
        this.Key = new int[100];
        this.ConId = new int[1000];
        this.ConRate = new int[1000];
    }
}
