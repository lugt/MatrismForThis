package matrism;

import java.io.*;

/**
 *
 * Created by God on 2016/6/16.
 *
 */
public class BrainLayers {
    /*

    G1 IO Layer
    G2 Action Loop
    G3 Selective / Fast Deci. Loop
    G4 Higher Selective
    G5 Strategic Loop

     */
    public static BrLayer G1 = new BrLayer();
    public static BrLayer G2 = new BrLayer();
    public static BrLayer G3 = new BrLayer();
    public static BrLayer G4 = new BrLayer();
    public static BrLayer G5 = new BrLayer();

    public static void LoadLayers(BrainLayers bL){
        // Load Layers From Saved File.
        File file = new File("def-la0.i");
        if(file.exists()){
            G1 = (BrLayer) readObjectFromFile("def-la0.i");
        }else{
            G1.initialize();
        }
    }

    public static void writeObjectToFile(Object obj,String fn)
    {
        File file =new File(fn);
        FileOutputStream out;
        try {
            out = new FileOutputStream(file);
            ObjectOutputStream objOut=new ObjectOutputStream(out);
            objOut.writeObject(obj);
            objOut.flush();
            objOut.close();
            System.out.println("write object success!");
        } catch (IOException e) {
            System.out.println("write object failed");
            e.printStackTrace();
        }
    }

    public static Object readObjectFromFile(String fn)
    {
        Object temp=null;
        File file =new File(fn);
        FileInputStream in;
        try {
            in = new FileInputStream(file);
            ObjectInputStream objIn=new ObjectInputStream(in);
            temp=objIn.readObject();
            objIn.close();
            System.out.println("read object success!");
        } catch (IOException e) {
            System.out.println("read object failed");
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return temp;
    }
}
