package matrism;

/**
 * Created by God on 2016/6/16.
 */
public class BrLayer {
    public static Cellular[] Ps;
    public void initialize() {
        Ps = new Cellular[1000];
        for (int i = 0; i < 1000 ; i++) {
            Ps[i] = new Cellular();
            Excecutor._(i,97);
        }
    }
}
