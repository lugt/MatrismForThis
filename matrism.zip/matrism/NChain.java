package matrism;

/**
 * Created by God on 2016/7/6.
 */
public class NChain {
    //  So Called Chain(Chain Invokes)


    Chain(Start) -N1 - N2- N3- N4- N5- N6- (Start)


}
