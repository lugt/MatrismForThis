package matrism;

/**
 * Created by God on 2016/7/6.
 */
public class Mirrorer {
    // Create "copy" of the existing chain;
    //
}
